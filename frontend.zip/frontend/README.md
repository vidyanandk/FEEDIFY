-- in server
npm init --yes
npm i express mongoose dotenv nodemon cors
npm i bcrypt  
npm i jsonwebtoken cookie-parser

-- in feedify
npm install
npm i react-router-dom axios
npm install react-hot-toast